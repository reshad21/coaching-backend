{
    "name": "ADMIN",
    "status": "ACTIVE",
    "features": [
      {
        "path": "/notice-control",
        "childPaths": [
          { "path": "/notice-control/create" },
          { "path": "/notice-control/delete" }
        ]
      }
    ]
  }