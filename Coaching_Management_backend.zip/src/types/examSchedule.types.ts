export type ExamScheduleData = {
    title?: string;
    file?: string;
  };